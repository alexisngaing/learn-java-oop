package gdisp_b_11407;

public interface IMengajarPraktikum {
    public void MengajarPraktikum();
}
