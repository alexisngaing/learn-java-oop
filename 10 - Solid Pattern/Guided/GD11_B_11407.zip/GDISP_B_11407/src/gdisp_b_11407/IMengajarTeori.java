package gdisp_b_11407;

public interface IMengajarTeori {
    public void MengajarTeori();
}
