package gdold_b_11407;

public abstract class Pengajar {
    protected String namaPengajar;

    public Pengajar(String namaPengajar) {
        this.namaPengajar = namaPengajar;
    }

    public abstract void showPengajar();
}
