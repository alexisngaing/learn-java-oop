package gdnonsolid_b_11407;

public interface IMengajar {
    public void MengajarTeori();
    public void MengajarPraktikum();
}
